# Results Summary

All values correspond to the final revised manuscript (Round 2, *Discover Food*).

## Dataset
- 25,615 RASFF notifications (2019–2025); 69.9% serious risk rate.
- Strict 80/20 temporal split: 20,492 train (71.2% serious) / 5,123 test (64.8% serious).
- Features engineered on training data only (leakage prevention).

## Classification (12 model configurations, bootstrap 95% CI)
- **LightGBM** — highest AUC-ROC (primary metric): 0.8970 [0.8884, 0.9052]; Acc 0.8087; F1 0.8077.
- LightGBM is best on AUC-ROC; XGBoost is marginally higher on accuracy/F1; balanced Random Forest is higher on precision.
- See `tables/table02_model_comparison.csv`.

## Ablation (`tables/table03_ablation.csv`)
| Configuration | Features | AUC-ROC | ΔAUC vs Full |
|---|---|---|---|
| Full | 26 | 0.8761 | baseline |
| Without Notification Type | 25 | 0.7871 | −0.089 |
| Without Historical Risk (PRIMARY) | 18 | 0.8970 | +0.021 |
| Without Both (Minimal / early-prediction) | 17 | 0.7993 | −0.077 |

## SHAP (`tables/table04_shap_importance.csv`)
Top features (18-feature primary model, cumulative %): Notification Type 1.86 (47.2%), Hazard Type 0.83 (68.2%), Year 0.37 (77.7%), Product Type 0.33 (86.1%), Notifying Country 0.19 (90.9%). Cumulative importance is strictly monotonic to 100%.

## Granger temporal precedence (`tables/table05_granger.csv`)
Bonferroni threshold p < 0.05/30 = 0.00167. **Three** relationships are significant:
1. Pathogenic Microorganisms → Migration (F = 17.91) — strongest
2. Food Additives → Pesticides (F = 15.37)
3. Heavy Metals → Migration (F = 11.14)
Interpreted as predictive temporal precedence, not causation.

## What-if sensitivity (`tables/table08_whatif_sensitivity.csv`)
EU-harmonization (origin controls): baseline 66.22% → 62.32% = −3.90 pp (−5.89% relative).

## Multi-target prediction (`tables/table07_multitarget.csv`)
Independent classifiers (multi-output, not joint MTL): Risk severity Acc 0.8087; Hazard type Acc 0.5963 / F1 0.5549 (+616% vs random); Notification type Acc 0.6502 / F1 0.6445 (+160% vs random).

## Conformal prediction (`tables/table06_conformal.csv`)
Temporal calibration set (last 20% of training, 4,098 samples). Empirical coverage 87.53% at 90% nominal → 2.47 pp under-coverage (expected under non-exchangeability of time-ordered data).
